import datetime
import csv
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
field1="UYFGYSDUFG"
field2="UIHG"
field3="uDSHG"
path="C:\\Users\\yashu\\Desktop\\csv_logs\\"

#--------
fromaddr = "yashugupta.gupta11@gmail.com"
toaddr = "anmolgarg088@gmail.com"
#--------------

def emails_Send(fromaddr,toaddr,email_file_name):
    msg = MIMEMultipart()
    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = "hello anmol wass up"
    body = "Body_of_the_mail"
    msg.attach(MIMEText(body, 'plain'))

    # open the file to be sent
    filename = "2018-12-08.csv"
    attachment = open("C:\\Users\\yashu\\Desktop\\csv_logs\\"+email_file_name, "rb")

    # instance of MIMEBase and named as p
    p = MIMEBase('application', 'octet-stream')

    # To change the payload into encoded form
    p.set_payload((attachment).read())

    # encode into base64
    encoders.encode_base64(p)

    p.add_header('Content-Disposition', "attachment; filename= %s" % filename)

    # attach the instance 'p' to instance 'msg'
    msg.attach(p)

    # creates SMTP session
    s = smtplib.SMTP('smtp.gmail.com', 587)

    # start TLS for security
    s.starttls()

    # Authentication
    s.login(fromaddr, "Y@7508boggu*1234")

    # Converts the Multipart msg into a string
    text = msg.as_string()

    # sending the mail
    s.sendmail(fromaddr, toaddr, text)


def email_func(a,b,c,fromaddr,toaddr):
    fields=[]
    fields.append(a)
    fields.append(b)
    fields.append(c)
    current_date = str(datetime.date.today())
    date_csv = []
    os.chdir(path)
    for p, n, f in os.walk(os.getcwd()):
        for a in f:
            a = str(a)
            if a.endswith('.csv'):
                date_csv.append(a)

    if len(date_csv) ==0:
        print("yoyo")
        with open(current_date + '.csv', 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(fields)
    if len(date_csv) >0:
        _date_filename = date_csv[0].replace(".csv", "")
        if _date_filename!=current_date:
            with open(current_date + '.csv', 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(fields)
            if os.path.exists(date_csv[0]):
                '''email code TODO'''
                emails_Send(fromaddr,toaddr,date_csv[0])
                os.remove(date_csv[0])

        else:
            print(_date_filename)
            if current_date == _date_filename:
                print("true")
                with open(current_date + '.csv', 'a', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(fields)
            else:
                if os.path.exists(date_csv[0]):

                    '''email code TODO'''
                    emails_Send(fromaddr,toaddr,date_csv[0])
                    os.remove(date_csv[0])


result=email_func(field1,field2,field3,fromaddr,toaddr)

current_date=str(datetime.date.today())
# print(current_date)
# print(type(current_date))
import os
import glob

# import os
# date_csv=[]
# os.chdir(path)
# for p,n,f in os.walk(os.getcwd()):
#     for a in f:
#         a = str(a)
#         if a.endswith('.csv'):
#             date_csv.append(a)
# _date=date_csv[0].replace(".csv","")
# print(_date)
# if current_date ==_date:
#     print("true")
# else:
#     if os.path.exists(date_csv[0]):
#         os.remove(date_csv[0])


